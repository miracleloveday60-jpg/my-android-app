package fanliteapp.m;
import android.app.admin.DeviceAdminReceiver;

public class MyDeviceAdminReceiver extends DeviceAdminReceiver {
}
